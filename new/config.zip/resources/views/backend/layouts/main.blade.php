@include('backend.layouts.header')

@include('backend.layouts.navbar')
        <!-- / Navbar -->
@yield('content')
</div>
<!-- / Layout page -->
</div>

</div>
<!-- / Layout wrapper -->

@include('backend.layouts.script')

</body>

</html>


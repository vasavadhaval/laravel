@include('frontend.layouts.header')

@include('frontend.layouts.navbar')
        <!-- / Navbar -->
@yield('content')
</div>
<!-- / Layout page -->
</div>

</div>
<!-- / Layout wrapper -->

@include('frontend.layouts.footer')

</body>

</html>


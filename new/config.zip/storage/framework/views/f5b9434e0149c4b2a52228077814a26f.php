<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">Users /</span> User Details
        </h4>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <!-- User Avatar -->
                        <img src="<?php echo e($user->avatar_url); ?>" class="img-fluid mb-3" alt="User Avatar">
                    </div>
                    <div class="col-md-8">
                        <!-- User Details -->
                        <h5 class="card-title">User Details</h5>
                        <ul class="list-group">
                            <li class="list-group-item"><strong>Name:</strong> <?php echo e($user->name); ?></li>
                            <li class="list-group-item"><strong>Email:</strong> <?php echo e($user->email); ?></li>
                            <li class="list-group-item"><strong>Role:</strong> <?php echo e($user->role); ?></li>
                            <!-- Add more details as needed -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\CuriousWheels\resources\views/backend/users/show.blade.php ENDPATH**/ ?>
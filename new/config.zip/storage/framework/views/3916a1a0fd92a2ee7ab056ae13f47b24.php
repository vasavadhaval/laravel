<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">Bookings /</span> Booking Details
        </h4>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Booking Details -->
                        <h5 class="card-title">Booking Details</h5>
                        <ul class="list-group">
                            <li class="list-group-item"><strong>ID:</strong> <?php echo e($booking->id); ?></li>
                            <li class="list-group-item"><strong>Vehicle:</strong> <?php echo e($booking->vehicle->make); ?></li>
                            <li class="list-group-item"><strong>User:</strong> <?php echo e($booking->user->name); ?></li>
                            <li class="list-group-item"><strong>Start Date:</strong> <?php echo e($booking->start_date); ?></li>
                            <li class="list-group-item"><strong>End Date:</strong> <?php echo e($booking->end_date); ?></li>
                            <li class="list-group-item"><strong>Pickup Location:</strong> <?php echo e($booking->pickup_location); ?></li>
                            <li class="list-group-item"><strong>Status:</strong> <?php echo e($booking->booking_status); ?></li>
                            <!-- Add more details as needed -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dhaval\CuriousWheels\resources\views/backend/booking/show.blade.php ENDPATH**/ ?>
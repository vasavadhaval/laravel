
<?php echo $__env->make('backend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">
            <?php echo $__env->make('backend.layouts.sidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Layout container -->
            <div class="layout-page">
<?php /**PATH D:\xampp\htdocs\laravel\CuriousWheels\resources\views/backend/layouts/header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<style>
    .blog-area {
    background: #ffffff !important;
}
</style>
<!-- ***** Breadcrumb Area Start ***** -->
<section class="section breadcrumb-area bg-overlay d-flex align-items-center blog">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Breadcrumb Content -->
                <div class="breadcrumb-content d-flex flex-column align-items-center text-center">
                    <h3 class="text-white"><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?></h3>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('user.home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('public.vehicles.index')); ?>">Vehicles</a></li>
                        <li class="breadcrumb-item active"><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="blog" class="section blog-area ptb_100">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-3">
                <aside class="sidebar">
                    <!-- Single Widget -->

                    <!-- Single Widget -->

                    <!-- Single Widget -->
                    <div class="single-widget">
                        <!-- Category Widget -->
                        <div class="accordions widget catagory-widget" id="cat-accordion">
                            <div class="single-accordion blog-accordion">
                                <h5>
                                    <a role="button" class="collapse show text-uppercase d-block p-3" data-toggle="collapse" href="#accordion1">Categories
                                    </a>
                                </h5>
                                <!-- Category Widget Content -->
                                <div id="accordion1" class="accordion-content widget-content collapse show" data-parent="#cat-accordion">
                                    <!-- Category Widget Items -->
                                    <ul class="widget-items">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('public.vehicle_types.show', $category->id)); ?>" class="d-flex p-3 <?php echo e($category->id == $vehicle->type ? 'active' : ''); ?>">
                                                    <span><?php echo e($category->name); ?></span>
                                                    <span class="ml-auto">(<?php echo e($category->vehicles_count); ?>)</span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>



                                </div>
                            </div>
                        </div>
                    </div>


                </aside>
            </div>
            <div class="col-12 col-lg-9 card p-2">
                <!-- Single Blog Details -->
                <article class="single-blog-details">
                    <!-- Blog Thumb -->
                    <div class="blog-thumb">
                        <a href="#"><img src="<?php echo e($vehicle->image_url); ?>" alt=""></a>
                    </div>
                    <!-- Blog Content -->
                    <div class="blog-content prolend-blog">
                        <!-- Meta Info -->
                        <div class="meta-info d-flex flex-wrap align-items-center py-2">
                            <ul>
                                <li class="d-inline-block p-2">By <a href="#">Dayane Mic</a></li>
                                <li class="d-inline-block p-2"><a href="#">05 Feb, 2018</a></li>
                                <li class="d-inline-block p-2"><a href="#">2 Comments</a></li>
                            </ul>
                            <!-- Blog Share -->
                            <div class="blog-share ml-auto d-none d-sm-block">
                                <!-- Social Icons -->
                                <div class="social-icons d-flex justify-content-center">
                                    <a class="bg-white facebook" href="#">
                                        <!-- Facebook Icon -->
                                    </a>
                                    <a class="bg-white twitter" href="#">
                                        <!-- Twitter Icon -->
                                    </a>
                                    <a class="bg-white google-plus" href="#">
                                        <!-- Google Plus Icon -->
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- Blog Details -->
                        <div class="blog-details">
                            <h3 class="blog-title my-3"><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?></h3>
                            <!-- Badge labels for vehicle details -->
                            <div class="demo-inline-spacing">
                                <span class="badge rounded-pill bg-label-primary">Year: <?php echo e($vehicle->year); ?></span>
                                <span class="badge rounded-pill bg-label-secondary">Capacity: <?php echo e($vehicle->capacity); ?></span>
                                <span class="badge rounded-pill bg-label-success">Availability: <?php echo e($vehicle->availability); ?></span>
                                <?php if($vehicle->vehiclelocation): ?>
                                    <span class="badge bg-label-dark" style="white-space: normal; line-height: normal; text-align: left;">Location: <?php echo e($vehicle->vehiclelocation->address); ?></span>
                                <?php endif; ?>
                            </div>
                            <!-- Vehicle description -->
                            <p><?php echo e($vehicle->description); ?></p>
                            <!-- Book now button -->
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <a href="<?php echo e(route('checkout.show', $vehicle)); ?>" class="blog-btn">Book now</a>
                                <span class="badge bg-label-danger">Price: ₹ <?php echo e($vehicle->price); ?> / <?php echo e($vehicle->rental_pricing_model); ?></span>
                            </div>
                        </div>
                    </div>
                </article>

            </div>
        </div>
    </div>
</section>
<!-- ***** Blog Area End ***** -->

<?php echo $__env->make('frontend.layouts.sitefooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\CuriousWheels\resources\views/frontend/vehicles/show.blade.php ENDPATH**/ ?>
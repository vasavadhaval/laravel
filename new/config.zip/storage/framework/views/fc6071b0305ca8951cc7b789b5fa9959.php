<?php $__env->startSection('content'); ?>

<!-- ***** Breadcrumb Area Start ***** -->
<section class="section breadcrumb-area bg-overlay d-flex align-items-center blog">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Breadcrumb Content -->
                <div class="breadcrumb-content d-flex flex-column align-items-center text-center">
                    <h3 class="text-white">Search Results</h3>
                    <!-- Display the search query if available -->
                    <?php if(!empty($searchQuery)): ?>
                    <p class="text-white">Results for: <strong><?php echo e($searchQuery); ?></strong></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** Breadcrumb Area End ***** -->

<?php if($vehicles->isEmpty()): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-danger my-5">
                <div class="card-body text-center">
                    <h5 class="card-title text-danger">No vehicles found</h5>
                    <p class="card-text">Please try a different search query.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>

<!-- ***** Blog Area Start ***** -->
<section id="blog" class="section blog-area ptb_100 blog">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-4">
                <!-- Single Blog -->
                <div class="single-blog res-margin">
                    <!-- Blog Thumb -->
                    <div class="blog-thumb">
                        <a href="<?php echo e(route('public.vehicles.show', $vehicle->id)); ?>"><img src="<?php echo e($vehicle->image_url); ?>" alt=""></a>
                    </div>
                    <!-- Blog Content -->
                    <div class="blog-content p-4">
                        <h3 class="blog-title my-3"><a href="<?php echo e(route('public.vehicles.show', $vehicle->id)); ?>"><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?></a></h3>
                        <!-- Badge labels for vehicle details -->
                        <div class="demo-inline-spacing">
                            <span class="badge rounded-pill bg-label-primary">Year: <?php echo e($vehicle->year); ?></span>
                            <span class="badge rounded-pill bg-label-secondary">Capacity: <?php echo e($vehicle->capacity); ?></span>
                            <span class="badge rounded-pill bg-label-success">Availability: <?php echo e($vehicle->availability); ?></span>
                            <?php if($vehicle->vehiclelocation): ?>
                            <span class="badge bg-label-dark" style="
                                white-space: normal;
                                line-height: normal;
                                text-align: left;
                            ">Location: <?php echo e($vehicle->vehiclelocation->address); ?></span>
                            <?php endif; ?>
                        </div>
                        <!-- Vehicle description -->
                        <p><?php echo e($vehicle->description); ?></p>
                        <!-- Book now button -->
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('public.vehicles.show', $vehicle->id)); ?>" class="blog-btn mt-3">Book now</a>
                            <span class="badge bg-label-danger mt-3">Price: ₹ <?php echo e($vehicle->price); ?> / <?php echo e($vehicle->rental_pricing_model); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- ***** Blog Area End ***** -->

<?php endif; ?>
<?php echo $__env->make('frontend.layouts.sitefooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dhaval\CuriousWheels\resources\views/frontend/vehicles/search.blade.php ENDPATH**/ ?>
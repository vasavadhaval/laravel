<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">Blogs /</span> Blog Details
        </h4>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <!-- Blog Image -->
                        <img src="<?php echo e($blog->image_url); ?>" class="img-fluid mb-3" alt="Blog Image">
                    </div>
                    <div class="col-md-8">
                        <!-- Blog Details -->
                        <h5 class="card-title">Blog Details</h5>
                        <ul class="list-group">
                            <li class="list-group-item"><strong>Title:</strong> <?php echo e($blog->title); ?></li>
                            <li class="list-group-item"><strong>Content:</strong> <?php echo e($blog->content); ?></li>
                            <li class="list-group-item"><strong>Author:</strong> <?php echo e($blog->author); ?></li>
                            <!-- Add more details as needed -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\CuriousWheels\resources\views/backend/blogs/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<!-- ***** Breadcrumb Area Start ***** -->
<section class="section breadcrumb-area bg-overlay d-flex align-items-center blog">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Breadcrumb Content -->
                <div class="breadcrumb-content d-flex flex-column align-items-center text-center">
                    <h3 class="text-white">Vehicles</h3>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('user.home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Vehicles</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** Breadcrumb Area End ***** -->


        <!-- ***** Blog Area Start ***** -->
        <section id="blog" class="section blog-area ptb_100 blog">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6">
                        <!-- Single Blog -->
                        <div class="single-blog res-margin">
                            <!-- Blog Thumb -->
                            <div class="blog-thumb">
                                <a href="<?php echo e(route('public.vehicles.show', $vehicle->id)); ?>"><img src="<?php echo e($vehicle->image_url); ?>" alt=""></a>
                            </div>
                            <!-- Blog Content -->
                            <div class="blog-content p-4">
                                <h3 class="blog-title my-3"><a href="<?php echo e(route('public.vehicles.show', $vehicle->id)); ?>"><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?></a></h3>
                                <!-- Badge labels for vehicle details -->
                                <div class="demo-inline-spacing">

                                    <span class="badge rounded-pill bg-label-secondary" style="    font-size: 16px;"><?php echo e($vehicle->year); ?> Model</span>
                                    <span class="badge rounded-pill bg-label-secondary" style="font-size: 16px;">Type: <?php echo e($vehicle->vehicleType->name); ?></span>
                                    <span class="badge rounded-pill bg-label-secondary" style="font-size: 16px;">Capacity: <?php echo e($vehicle->capacity); ?></span></br>
                                    <?php if($vehicle->vehiclelocation): ?>
                                    <span class="badge bg-label-dark" style="
                                        margin: 13px 0px 13px !important;
                                        white-space: normal;
                                        font-size: 16px;
                                        line-height: normal;
                                        text-align: left;
                                        width: 100%;
                                    "><b>Location: </b></br> <?php echo e($vehicle->vehiclelocation->address); ?></span>
                                    <?php endif; ?>
                                </div>
                                <!-- Vehicle description -->
                                <p class="" style="    font-size: 16px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($vehicle->description); ?></p>
                                <!-- Book now button -->
                                <div class="d-flex justify-content-between">
                                    <a href="<?php echo e(route('checkout.show', $vehicle)); ?>" class="blog-btn btn-primary mt-3  pr-5" style="padding: 12px; font-size: 20px;border-radius: 0.25rem;">Book Now</a>
                                    <span class="badge bg-label-danger mt-3" style="
                                    padding: 18px;
                                    font-size: 21px;
                                ">₹ <?php echo e($vehicle->price); ?> /day</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
        <!-- ***** Blog Area End ***** -->
    <!--====== Footer Area Start ======-->
    <footer class="footer-area dark-bg">
        <!-- Footer Top -->
        <div class="footer-top ptb_100">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-6 col-lg-3">
                        <!-- Footer Items -->
                        <div class="footer-items">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img class="logo" src="<?php echo e(asset('frontend/assets/img/logo/logo-white.png')); ?>"
                                    alt="">
                            </a>
                            <p class="mt-2 mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit laboriosam vitae.
                            </p>
                            <!-- Social Icons -->
                            <div class="social-icons d-flex">
                                <a class="facebook" href="#">
                                    <i class="fab fa-facebook-f"></i>
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a class="twitter" href="#">
                                    <i class="fab fa-twitter"></i>
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a class="google-plus" href="#">
                                    <i class="fab fa-google-plus-g"></i>
                                    <i class="fab fa-google-plus-g"></i>
                                </a>
                                <a class="vine" href="#">
                                    <i class="fab fa-vine"></i>
                                    <i class="fab fa-vine"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-3">
                        <!-- Footer Items -->
                        <div class="footer-items">
                            <!-- Footer Title -->
                            <h3 class="footer-title mb-2">Company</h3>
                            <ul>
                                <li class="py-2"><a href="#">About Us</a></li>
                                <li class="py-2"><a href="#">Our Services</a></li>
                                <li class="py-2"><a href="#">Career</a></li>
                                <li class="py-2"><a href="#">Read our Blog</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-3">
                        <!-- Footer Items -->
                        <div class="footer-items">
                            <!-- Footer Title -->
                            <h3 class="footer-title mb-2">Support</h3>
                            <ul>
                                <li class="py-2"><a href="#">Legal Information</a></li>
                                <li class="py-2"><a href="#">Privacy Policy</a></li>
                                <li class="py-2"><a href="#">Terms &amp; Conditions</a></li>
                                <li class="py-2"><a href="#">Report Abuse</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-3">
                        <!-- Footer Items -->
                        <div class="footer-items">
                            <!-- Footer Title -->
                            <h3 class="footer-title mb-2">Get In touch</h3>
                            <ul>
                                <li class="py-2">
                                    <a class="media" href="#">
                                        <div class="social-icon mr-3">
                                            <i class="fas fa-home"></i>
                                        </div>
                                        <span class="media-body align-self-center">27 Lakeshore Court, Mooresville, NC
                                            28115</span>
                                    </a>
                                </li>
                                <li class="py-2">
                                    <a class="media" href="#">
                                        <div class="social-icon mr-3">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                        <span class="media-body align-self-center">+1 230 456 789-012 6789</span>
                                    </a>
                                </li>
                                <!-- Subscribe Form -->
                                <div class="subscribe-form d-flex align-items-center mt-3">
                                    <input type="email" class="form-control" placeholder="Enter Email">
                                    <button type="submit" class="btn btn-yellow"><i
                                            class="fas fa-location-arrow"></i></button>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- Copyright Area -->
                        <div
                            class="copyright-area d-flex flex-wrap justify-content-center justify-content-sm-between text-center py-4">
                            <!-- Copyright Left -->
                            <div class="copyright-left">&copy; Copyrights 2020 Prolend All rights reserved.</div>
                            <!-- Copyright Right -->
                            <div class="copyright-right">Made with <i class="fas fa-heart"></i> By <a
                                    href="#">Theme Land</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--====== Footer Area End ======-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\CuriousWheels\resources\views/frontend/vehicles/index.blade.php ENDPATH**/ ?>
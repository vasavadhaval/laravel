<?php
namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller
{
        public function index()
        {
            $bookings = Booking::all(); // Fetch all bookings
            return view('backend.bookings.index', compact('bookings'));
        }

    public function store(Request $request)
    {
        // Validation logic for the booking form data
        $request->validate([
            'vehicle_id' => 'required|exists:vehicles,id',
            'user_id' => 'required|exists:users,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            // Add more validation rules for additional form fields if needed
        ]);

        // Create a new booking record
        $booking = Booking::create([
            'vehicle_id' => $request->input('vehicle_id'),
            'user_id' => $request->input('user_id'),
            'start_date' => $request->input('start_date'),
            'end_date' => $request->input('end_date'),
            // Add more fields as needed
        ]);

        // Redirect or return a response based on the result
        if ($booking) {
            return redirect()->route('booking.success')->with('success', 'Booking successful!');
        } else {
            return back()->with('error', 'Failed to create booking. Please try again.');
        }
    }

    // Other methods like edit, update, delete, etc., as needed
}

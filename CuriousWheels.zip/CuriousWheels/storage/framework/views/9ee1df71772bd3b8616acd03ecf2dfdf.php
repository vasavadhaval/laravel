<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('backend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Navbar -->
<?php echo $__env->yieldContent('content'); ?>
</div>
<!-- / Layout page -->
</div>

</div>
<!-- / Layout wrapper -->

<?php echo $__env->make('backend.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>

<?php /**PATH D:\xampp\htdocs\laravel\CuriousWheels\resources\views/backend/layouts/main.blade.php ENDPATH**/ ?>
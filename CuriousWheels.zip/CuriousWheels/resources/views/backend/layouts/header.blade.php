
@include('backend.layouts.head')
<body>

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">
            @include('backend.layouts.sidbar')
            <!-- Layout container -->
            <div class="layout-page">
